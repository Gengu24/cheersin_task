package cheersin;

import java.io.IOException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import pageModules.Common_Functions;
import pageModules.cheersIn.Invoke;
import pageModules.cheersIn.UserActivity;
import testBase.TestBase;

public class Gmail extends TestBase {

	@SuppressWarnings("static-access")
	@Test
	public static void main() throws Exception {

		try {
			Common_Functions.startRecording(cheersinvideofile);
			new UserActivity().gmail_activity();
			Common_Functions.stopRecording();
		} catch (Exception e) {
			Common_Functions.stopRecording();
		}

	}

	@BeforeClass
	public void beforesuite() throws IOException, InterruptedException, FilloException {
		Common_Functions.videorecording(cheersinimage, cheersinvideofile);

		Invoke.Invoke_Project("Chrome", "Gmail");

	}

}
