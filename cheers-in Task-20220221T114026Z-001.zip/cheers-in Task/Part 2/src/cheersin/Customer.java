package cheersin;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.relevantcodes.extentreports.ExtentReports;

import pageModules.Common_Functions;
import pageModules.cheersIn.Invoke;
import pageModules.cheersIn.UserActivity;
import testBase.TestBase;

public class Customer extends TestBase {
	public static String Cheersin = "CUSTOMER";

	@DataProvider
	
	public static String readtestcase_cheersin(String project, String value) throws FilloException {
		if(isExecutable == true) {
			readtestcase(project, value);
			while(recrd.next()) {
				testcaseid = recrd.getField("Iteration");
				runmode = recrd.getField("Runmode");
				CustomerName = recrd.getField("CustomerName");
				SegmentName = recrd.getField("SegmentName");
				ServiceType = recrd.getField("ServiceType");
				MobileNumber = recrd.getField("MobileNumber");
				PrimaryEmail = recrd.getField("PrimaryEmail");
				CommunicationPin = recrd.getField("CommunicationPin");
				CommunicationArea = recrd.getField("CommunicationArea");
				CommunicationBuilding = recrd.getField("CommunicationBuilding");
				CommunicationState = recrd.getField("CommunicationState");
				CommunicationCity = recrd.getField("CommunicationCity");
				OrganizationDetails = recrd.getField("OrganizationDetails");
				AlternatePhone = recrd.getField("AlternatePhone");
				Landline = recrd.getField("Landline");
				AssociationName = recrd.getField("AssociationName");
				AssociationContact = recrd.getField("AssociationContact");
				AssociationEmail = recrd.getField("AssociationEmail");
				
			}
		}
		return runmode;
	}
	
	
	@SuppressWarnings("static-access")
	@Test
	public static void main1000() throws Exception {
		tcid = Thread.currentThread().getStackTrace()[1].getMethodName();
		System.out.println("Testcase id = "+tcid);
		test = extent.startTest(tcid);
		String val = readtestcase_cheersin(Cheersin, tcid);
		if(val.equalsIgnoreCase("Yes")) {
			try {
				Common_Functions.startRecording(cheersinvideofile);
				new UserActivity().customer_activity();
				Common_Functions.stopRecording();
			} catch (Exception e) {
				Common_Functions.stopRecording();
			}
		}
	}
	
	@BeforeClass
	public void beforesuite() throws NoSuchMethodException, SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException, FilloException, InterruptedException, IOException {
		Common_Functions.videorecording(cheersinimage, cheersinvideofile);

		readexcel("CUSTOMER");

		if (isExecutable == true) {

			extendedhtml = System.getProperty("user.dir") + "\\OutputReports\\IWMSBAT-" + GeneratedValue
					+ ".html";
			extent = new ExtentReports(extendedhtml);
			Invoke.Invoke_Project("Chrome", "Cheersin");

		} else {

			Common_Functions.logMessage("exe:false");
			throw new SkipException("THESE TESTS ARE NOT INTENDED TO EXECUTE: ");

		}
	}

}
