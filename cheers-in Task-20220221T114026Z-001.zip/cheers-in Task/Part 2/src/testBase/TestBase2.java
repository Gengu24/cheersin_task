package testBase;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pageModules.Common_Functions;

public class TestBase2

{
	public static WebDriver driver;
	
	/**For Extended Reports*/
	public static String img = "";
	public static String imgfail = "";
	public static ExtentReports extent;
	public static ExtentReports logger;
	public static ExtentTest test;
	
	/**For Excel Reader*/
	public static boolean isExecutable;
	public static String TestNames = "";
	public static String TestNamesRunMode = "";	
	public static org.testng.log4testng.Logger APP_LOGS = null;
	public static Properties CONFIG = null;
	public static Properties OR = null;
	public static int count = -1;
	public static boolean skip = false;
	public static boolean isInitialized = false;
	public static boolean fail = false;
	
	/**For Test case Reader*/
	public static String comments = "";
	public static String status = "";
	public static String docID = "14A7E52D";
	public static String tcc = "";
	public static String testcaseid = "";
	public static String queryresult = "";
	public static String inputfile = "";
	public static String val = "";
	public static String tcid = "";
	public static String iter = "";
	public static String runmode = "";
	public static String description = "";
	public static String browser = "";
	public static String input = "";
	public static String modifytext = "";
	public static String PrimaryAction = "";
	public static String SecondaryAction = "";
	public static String customername = "";
	public static String attachmentstatus = "";
	public static String project;
	public static String GeneratedValue = Common_Functions.returnTodayDateTime("ddMMYYYY-hhmmss");
	public static String XLS = "LeadSuite.xlsx";
	public static int a = 0;
	public static Recordset recrd;
	

	public static void readexcel(String proj) throws FilloException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException 
	{
		try {
			Fillo fillo = new Fillo();
			String inputfile = (System.getProperty("user.dir") + "\\InputData\\" + "LeadSuite.xlsx");
			Connection cn = fillo.getConnection(inputfile);
			queryresult = "select * from Execution where projectname = '" + proj + "'";
			project= proj;
			Recordset recr = cn.executeQuery(queryresult);
			while (recr.next()) {
				TestNames = recr.getField("Projectname");
				TestNamesRunMode = recr.getField("runmode");
				browser = recr.getField("Browser");
				if (TestNamesRunMode.equalsIgnoreCase("Y")) {
					isExecutable = true;
				} else {
					isExecutable = false;
				}
				System.out.println(browser);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}	

	public static Recordset readtestcase(String project, String value) throws FilloException
	{
			testcaseid = value.substring(value.length() - 4);
			Fillo fillo = new Fillo();
			String inputfile = (System.getProperty("user.dir") + "\\InputData\\" + XLS);
			Connection cn = fillo.getConnection(inputfile);
			queryresult = "select * from " + project + " where Iteration =" + testcaseid;
			recrd = cn.executeQuery(queryresult);
			return recrd;
	}

	public static void stepskip() throws IOException 
	{
		// test.log(Status.FAIL,value);
		test.log(LogStatus.SKIP, "Runmode = Skip");
	}
	
	public static String capture(String project,WebDriver driver) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String currentdate = Common_Functions.returnTodayDateTime("ddMMYYYY");
		String timestamp = Common_Functions.returnTodayDateTime("HHmmss");
		String dest = System.getProperty("user.dir") + "\\OutputReports\\"+project+"\\" + currentdate + "\\PrimaryAction"+ timestamp +".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		return dest;
	}
}

