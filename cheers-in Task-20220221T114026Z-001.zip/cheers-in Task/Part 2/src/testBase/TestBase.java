
package testBase;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Properties;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pageModules.Common_Functions;

public class TestBase

{
	public static WebDriver driver;

	/** For Extended Reports */
	public static String img = "";
	public static String imgfail = "";
	public static ExtentReports extent;
	public static ExtentReports logger;
	public static ExtentTest test;
	public static String extendedhtml;
	public static String role;
	

	/** For Excel Reader */
	public static boolean isExecutable;
	public static String TestNames = "";
	public static String TestNamesRunMode = "";
	public static org.testng.log4testng.Logger APP_LOGS = null;
	public static Properties CONFIG = null;
	public static Properties OR = null;
	public static int count = -1;
	public static boolean isInitialized = false;
	public static boolean fail = false;
	public static ArrayList<String> tabs;
	/** For Test case Reader */
	public static String comments = "";
	public static String status = "";
	public static String IWMS = "iWMS";
	public static String testcaseid = "";
	public static String queryresult = "";
	public static String inputfile = "";
	public static String val = "";
	public static String tcid = "";
	public static String iter = "";
	public static String runmode = "";

	

	public static String CustomerName = "";
	public static String SegmentName = "";
	public static String ServiceType = "";
	public static String MobileNumber = "";
	public static String PrimaryEmail = "";
	public static String CommunicationPin = "";
	public static String CommunicationArea = "";
	public static String CommunicationBuilding = "";
	public static String CommunicationState = "";
	public static String CommunicationCity = "";
	public static String OrganizationDetails = "";
	public static String AlternatePhone = "";
	public static String Landline = "";
	public static String AssociationName = "";
	public static String AssociationContact = "";
	public static String AssociationEmail = "";

	
	public static String attachmentstatus = "";
	public static String project;
	public static String GeneratedValue = Common_Functions.returnTodayDateTime("ddMMYYYY-hhmmss");
	public static String XLS = "LeadSuite.xlsx";
	public static int a = 0;
	public static Recordset recrd;
    public static String videofile;
    public static String currentdate = Common_Functions.returnTodayDateTime("ddMMYYYY");
	public static Connection cn;

	
	 
	
	/** cheersin **/
	 public static String cheersinfail =System.getProperty("user.dir")+ "\\OutputReports\\ErrorScreenshots\\cheersin\\";
	 public static  String  cheersinvideofile = System.getProperty("user.dir")+ "\\OutputVideo\\cheersin";
	
	 public static String cheersinimage = System.getProperty("user.dir") + "\\OutputReports\\cheersin\\" + currentdate;
	 public static String dynamicimage;
     public static String screenshotdesc ="";
     
	public static void readexcel(String proj) throws FilloException, NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		try {
			Fillo fillo = new Fillo();
			String inputfile = (System.getProperty("user.dir") + "\\InputData\\" + "LeadSuite.xlsx");
			cn = fillo.getConnection(inputfile);
			System.out.println("excel read method :" + proj);
			queryresult = "select * from Execution where projectname = '" + proj + "'";
			project = proj;
			Recordset recr = cn.executeQuery(queryresult);
			while (recr.next()) {
				TestNames = recr.getField("Projectname");
				TestNamesRunMode = recr.getField("runmode");
				System.out.println("Runmode " + TestNamesRunMode);
				if (TestNamesRunMode.equalsIgnoreCase("Y"))
				{
					isExecutable = true;
				} else {
					isExecutable = false;
				}
			}
		} catch (Exception e) {
			System.out.println("Exception message is ="+e);
		}
	}

	public static Recordset readtestcase(String project, String value) throws FilloException {
		testcaseid = value.substring(value.length() - 4);
		Fillo fillo = new Fillo();
		String inputfile = (System.getProperty("user.dir") + "\\InputData\\" + XLS);
		Connection cn = fillo.getConnection(inputfile);
		queryresult = "select * from " + project + " where Iteration =" + testcaseid;
		recrd = cn.executeQuery(queryresult);
		return recrd;
	}

//	public static void stepskip() throws IOException {
//		// test.log(Status.FAIL,value);
//		test.log(LogStatus.SKIP, "Runmode = Skip");
//	}

	public static String capture(String project, WebDriver driver) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String currentdate = Common_Functions.returnTodayDateTime("ddMMYYYY");
		String timestamp = Common_Functions.returnTodayDateTime("HHmmss");
		String dest = System.getProperty("user.dir") + "\\OutputReports\\" + project + "\\" + currentdate
				+ "\\"+tcid+"_"+screenshotdesc+ timestamp + ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		return dest;
	}

}

