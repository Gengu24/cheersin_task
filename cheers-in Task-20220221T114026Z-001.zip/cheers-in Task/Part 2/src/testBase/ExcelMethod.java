package testBase;


public class ExcelMethod extends TestBase
{
	
}
