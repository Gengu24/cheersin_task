package pageModules.cheersIn;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.codoid.products.exception.FilloException;
import pageModules.Common_Functions;
import testBase.TestBase;

public class Invoke extends TestBase {

	private static JavascriptExecutor js = (JavascriptExecutor) driver;

	/** For Gmail */

	@FindBy(xpath = "//h1/span[text()=\"Sign in\"]")
	public static WebElement Sign_In;

	@FindBy(xpath = "//div[text()=\"Email or phone\"]//preceding::input[@type=\"email\"]")
	public static WebElement User_name;

	@FindBy(xpath = "//span[text()=\"Next\"]/ancestor::button")
	public static WebElement Next;

	@FindBy(xpath = "//div[@id=\"profileIdentifier\"]")
	public static WebElement Password_Screen;

	@FindBy(xpath = "//div[text()=\"Enter your password\"]//preceding::input[@type=\"password\"]")
	public static WebElement User_Password;

	@FindBy(xpath = "//div[text()=\"Compose\"]")
	public static WebElement Compose_Button;

	@FindBy(xpath = "//div[@aria-label=\"New Message\"]")
	public static WebElement New_message;

	@FindBy(xpath = "//textarea[@aria-label=\"To\"]")
	public static WebElement To_address;

	@FindBy(xpath = "//input[@aria-label=\"Subject\"]")
	public static WebElement Subject;

	@FindBy(xpath = "//div[@aria-label=\"Message Body\"]")
	public static WebElement Message_body;

	@FindBy(xpath = "//div[@aria-label=\"Attach files\"]")
	public static WebElement Attach_files;

	@FindBy(xpath = "//input[@name=\"attach\"]//parent::div")
	public static WebElement Active_Attach;

	@FindBy(xpath = "//div[text()='Send']")
	public static WebElement Send_mail;

	/** For IRCTC */

	@FindBy(xpath = "//span[text()=\"Alert\"]/parent::div/parent::div")
	public static WebElement Alert_dialog;

	@FindBy(xpath = "//button[@type=\"submit\" and text()=\"OK\"]")
	public static WebElement Alert_OK;

	@FindBy(xpath = "//label[text()=\" BOOK TICKET \"]")
	public static WebElement Book_ticket;

	@FindBy(xpath = "//label[text()=\"From\"]/preceding-sibling::p-autocomplete/span/input")
	public static WebElement From_station;

	@FindBy(xpath = "//ul[@role=\"listbox\"]/descendant::li[@role=\"option\"]")
	public static String station_list;

	@FindBy(xpath = "//label[text()=\"To\"]/preceding-sibling::p-autocomplete/span/input")
	public static WebElement To_station;

	@FindBy(xpath = "//span[text()=\"GENERAL\"]/parent::div")
	public static WebElement Ticket_type;

	@FindBy(xpath = "//ul[@role=\"listbox\"]/descendant::p-dropdownitem/li[@role=\"option\"]/span")
	public static String Ticket_type_list;

	@FindBy(xpath = "//p-calendar/span/input")
	public static WebElement date_picker_box;

	@FindBy(css = "div[class*='trigger']>div[class*='datepicker']")
	public static WebElement date_picker;

	@FindBy(xpath = "//input[@aria-label=\"All Classes\"]/parent::div/parent::div")
	public static WebElement Seat_type;

	@FindBy(xpath = "//ul[@role=\"listbox\"]/descendant::p-dropdownitem/li[@role=\"option\"]/span")
	public static String Seat_type_list;

	@FindBy(xpath = "//label[text()=\"Train with Available Berth \"]")
	public static WebElement Check_box;

	@FindBy(xpath = "//button[text()=\"Search\"]")
	public static WebElement Search;

	@FindBy(xpath = "//div/span[contains(text(),'Results for')]")
	public static WebElement Search_Results;

	/** For Cheersin */

	@FindBy(xpath = "//input[@id=\"name\"]")
	public static WebElement Cust_name;

	@FindBy(xpath = "//input[@id=\"mobile\"]")
	public static WebElement Cust_mobile;

	@FindBy(xpath = "//input[@id=\"primaryemail\"]")
	public static WebElement Cust_primaryemail;

	@FindBy(xpath = "//input[@id=\"Communicationpincode\"]")
	public static WebElement Cust_commu_pincode;

	@FindBy(xpath = "//input[@id=\"Communicationarea\"]")
	public static WebElement Cust_commu_area;

	@FindBy(xpath = "//input[@id=\"Communicationbuilding\"]")
	public static WebElement Cust_commu_building;

	@FindBy(xpath = "//input[@id=\"Communicationstate\"]")
	public static WebElement Cust_commu_state;

	@FindBy(xpath = "//input[@id=\"Communicationcity\"]")
	public static WebElement Cust_commu_city;

	@FindBy(xpath = "//label[@class=\"checkbox-label\"]")
	public static WebElement Address_checkbox;

	@FindBy(xpath = "//input[@id=\"Orgnaization\"]")
	public static WebElement Cust_organization;

	@FindBy(xpath = "//input[@id=\"alternatemobile\"]")
	public static WebElement Cust_alt_mobile;

	@FindBy(xpath = "//input[@id=\"AssociationName\"]")
	public static WebElement Cust_landline;

	@FindBy(xpath = "//input[@id=\"AssociationName\"]")
	public static WebElement Cust_Association_name;

	@FindBy(xpath = "//input[@id=\"AssociationContact\"]")
	public static WebElement Cust_Association_contact;

	@FindBy(xpath = "//input[@id=\"AssociationEmail\"]")
	public static WebElement Cust_Association_email;

	public static WebDriverWait wait;

	public Invoke() {
		wait = new WebDriverWait(driver, 15, 50);
		// initialize elements
		PageFactory.initElements(driver, this);
	}

	public static void Invoke_Project(String browser, String Project)
			throws InterruptedException, IOException, FilloException {
		Common_Functions.Kill_Browser();
		String path = System.getProperty("user.dir");
		Common_Functions.logMessage("\n<------------Invoking Browser--------------->");

		// Set property for your browser
		if (browser.equalsIgnoreCase("Chrome")) {
			System.out.println("Hello");
			System.setProperty("webdriver.chrome.driver", path + "/Drivers/chromedriver.exe");
			driver = new ChromeDriver();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200",
					"--ignore-certificate-errors");
			Common_Functions.logMessage("Invoking Chrome...");
		} else if (browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", path + "/Drivers/geckodriver.exe");
			driver = new FirefoxDriver();
			Common_Functions.logMessage("Invoking Firefox...");
		} else if (browser.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.ie.driver", path + "/Drivers/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			Common_Functions.logMessage("Invoking IE...");
		} else {
			Common_Functions.logErroMessage_Stop("Wrong Browser name, please check the browser input.");
		}

		Thread.sleep(8000);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		Common_Functions.logMessage("browser maximized.");
		if (Project.equalsIgnoreCase("Gmail")) {
			driver.get("https://mail.google.com");
			if (driver.getTitle().equalsIgnoreCase("Gmail")) {
				Common_Functions.logMessage_withScreenshot("Login Page Landed Successfully");
			} else {
				Common_Functions.logErrorMessage("Check the URL entered");
			}
		} else if (Project.equalsIgnoreCase("Irctc")) {
			driver.get("https://www.irctc.co.in/nget/train-search");
			System.out.println("The title of the page is =" + driver.getTitle());
			if (driver.getTitle().contains("IRCTC")) {
				Common_Functions.logMessage_withScreenshot("Page Landed Successfully");
			} else {
				Common_Functions.logErrorMessage("Check the URL entered");
			}
		}

		else if (Project.equalsIgnoreCase("Cheersin")) {
			driver.get("https://customer.i-on.in:9443/signUp");
			System.out.println("The title of the page is =" + driver.getTitle());
			if (driver.getTitle().contains("ION | Broadband")) {
				Common_Functions.logMessage_withScreenshot("Page Landed Successfully");
			} else {
				Common_Functions.logErrorMessage("Check the URL entered");
			}
		}

	}

	public static void Login_gmail() throws InterruptedException {

		try {
			wait.until(ExpectedConditions.visibilityOf(Sign_In));
			Common_Functions.logMessage_withScreenshot("Login Page");
			User_name.sendKeys("gengutwilightit");
			Next.click();
			wait.until(ExpectedConditions.visibilityOf(Password_Screen));
			if (Password_Screen.getText().equalsIgnoreCase("gengutwilightit@gmail.com")) {
				Common_Functions.logMessage_withScreenshot("Password screen Landed successfully");
			} else {
				Common_Functions.logErrorMessage("Password screen not loaded");
			}
			User_Password.sendKeys("Gengu@123");
			Next.click();
			wait.until(ExpectedConditions.visibilityOf(Compose_Button));
			if (Compose_Button.getText().equalsIgnoreCase("Compose")) {
				Common_Functions.logMessage_withScreenshot("User Profile Loaded");
			} else {
				Common_Functions.logErrorMessage("User Profile not Loaded");
			}
		} catch (Exception e) {
			Common_Functions.logErrorMessage("Exception occurs" + e);
		}
	}

public static void Compose_mail() throws InterruptedException, IOException, AWTException {
	try {
		wait.until(ExpectedConditions.elementToBeClickable(Compose_Button)).click();
		if(New_message.isDisplayed()) {
			Common_Functions.logMessage_withScreenshot("New message box is opened");
		}
		else {
			Common_Functions.logErrorMessage("New message box not opened");
		}
		To_address.sendKeys("gengutwilightit@gmail.com");
		Subject.sendKeys("Welcome Subject");
		Message_body.sendKeys("Cheersin Welcomes you");
		Attach_files.click();
		//File upload section
		
		String imagefilename = Common_Functions.generateimagefile("\\FileUpload\\pdf\\"sample".pdf");
	    StringSelection textFile = new StringSelection(imagefilename);
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(textFile, null);

		Thread.sleep(8000);

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		Thread.sleep(8000);
		wait.until(ExpectedConditions.visibilityOf(Active_Attach));
		if(Active_Attach.isDisplayed()) {
			System.out.println("Attachment ="+Active_Attach.getText());
			Common_Functions.logMessage_withScreenshot("File uploaded successfully!");
		}
		else {
			Common_Functions.logErrorMessage("File not uploaded");
		}
		Send_mail.click();
	}
	catch(Exception e) {
		Common_Functions.logErrorMessage("Exception occurs"+e);
	}
	
}

	public static void Ticket_irctc() throws InterruptedException {

		try {
			wait.until(ExpectedConditions.visibilityOf(Alert_dialog));
			Common_Functions.logMessage_withScreenshot("IRCTC alert");
			Actions actn = new Actions(driver);
			actn.moveToElement(Alert_OK).perform();
			Alert_OK.click();
			wait.until(ExpectedConditions.visibilityOf(Book_ticket));
			From_station.sendKeys("shiva");
			Thread.sleep(2000);
			List<WebElement> from_list = driver
					.findElements(By.xpath("//ul[@role=\"listbox\"]/descendant::li[@role=\"option\"]"));
			System.out.println("Size of list =" + from_list.size());
			for (int i = 0; i < from_list.size(); i++) {
				System.out.println(from_list.get(i).getText());
				if (from_list.get(i).getText().contains("C SHIVAJI MAH T - CSMT")) {
					from_list.get(i).click();
					break;
				}
			}
			To_station.sendKeys("how");
			Thread.sleep(2000);
			List<WebElement> to_list = driver
					.findElements(By.xpath("//ul[@role=\"listbox\"]/descendant::li[@role=\"option\"]"));
			for (int i = 0; i < to_list.size(); i++) {
				System.out.println(to_list.get(i).getText());
				if (to_list.get(i).getText().contains("HOWRAH JN - HWH")) {
					to_list.get(i).click();
					break;
				}
			}
			Ticket_type.click();
			Thread.sleep(2000);
			List<WebElement> Type_list = driver
					.findElements(By.xpath("//ul[@role=\"listbox\"]/descendant::p-dropdownitem/li[@role=\"option\"]"));
			for (int i = 0; i < Type_list.size(); i++) {
				System.out.println(Type_list.get(i).getText());
				// if(Type_list.get(i).getText().contains("TATKAL")) {
				if (Type_list.get(i).getText().contains("GENERAL")) {
					Type_list.get(i).click();
					break;
				}
			}
			date_picker_box.clear();
			wait.until(ExpectedConditions.visibilityOf(date_picker));
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date();
			String todaysDate = dateFormat.format(date);
			System.out.println(todaysDate);

			String day = todaysDate.substring(0, 2);
			String month = todaysDate.substring(3, 5);

			int monthValue = Integer.parseInt(month);
			int dayValue = Integer.parseInt(day);

			int temp = 30 - dayValue;
			dayValue = 30 - temp;
			monthValue = monthValue + 1;

			String newDay = dayValue + "/" + monthValue + "/" + "2022";
			System.out.println("New date value is=" + newDay);
			date_picker_box.sendKeys(Keys.chord(Keys.CONTROL, "a"));
			date_picker_box.sendKeys(Keys.DELETE);
			date_picker_box.sendKeys(newDay);
			date_picker_box.sendKeys(Keys.ESCAPE);
			Seat_type.click();
			Thread.sleep(2000);
			List<WebElement> Seat_list = driver.findElements(
					By.xpath("//ul[@role=\"listbox\"]/descendant::p-dropdownitem/li[@role=\"option\"]/span"));
			for (int i = 0; i < Seat_list.size(); i++) {
				System.out.println(Seat_list.get(i).getText());
				if (Seat_list.get(i).getText().contains("AC 3 Tier (3A)")) {
					Seat_list.get(i).click();
					break;
				}
			}
			Check_box.click();
			Search.click();
			wait.until(ExpectedConditions.visibilityOf(Search_Results));
			if (Search_Results.isDisplayed()) {
				Common_Functions.logMessage_withScreenshot("Search Results loaded successfully");
			} else {
				Common_Functions.logErrorMessage("Search Results not loaded");
			}
		} catch (Exception e) {
			Common_Functions.logErrorMessage("Exception occurs" + e);
		}
	}

	public static void Customer_form() throws InterruptedException {

		try {

			Cust_name.sendKeys(CustomerName);
			Select Segment = new Select(driver.findElement(By.xpath("//select[@id=\"SelectSegment\"]")));
			Segment.selectByVisibleText(SegmentName);
			Thread.sleep(1000);
			Select Service = new Select(driver.findElement(By.xpath("//select[@id=\"ServiceType\"]")));
			Service.selectByVisibleText(ServiceType);
			Cust_mobile.sendKeys(MobileNumber);
			Cust_primaryemail.sendKeys(PrimaryEmail);
			Cust_commu_pincode.sendKeys(CommunicationPin);
			Cust_commu_area.sendKeys(CommunicationArea);
			Cust_commu_building.sendKeys(CommunicationBuilding);
			Cust_commu_state.sendKeys(CommunicationState);
			Cust_commu_city.sendKeys(CommunicationCity);
			Address_checkbox.click();
			Cust_organization.sendKeys(OrganizationDetails);
			Cust_alt_mobile.sendKeys(AlternatePhone);
			Cust_landline.sendKeys(Landline);
			Cust_Association_name.sendKeys(AssociationName);
			Cust_Association_contact.sendKeys(AssociationContact);
			Cust_Association_email.sendKeys(AssociationEmail);

		} catch (Exception e) {
			Common_Functions.logErrorMessage("Exception occurs" + e);
		}
	}
}
