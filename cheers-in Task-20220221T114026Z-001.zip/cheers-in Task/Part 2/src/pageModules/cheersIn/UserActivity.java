package pageModules.cheersIn;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import testBase.TestBase;

public class UserActivity extends TestBase {
	
	
	//public static WebDriverWait wait=new WebDriverWait(driver, a);
	public static WebDriverWait wait;

	public UserActivity() {
		wait = new WebDriverWait(driver, 15, 50);
		// initialize elements
		PageFactory.initElements(driver, this);
	}
	
	@SuppressWarnings({ "static-access" })
	public static void gmail_activity() throws Exception {
		  new Invoke();
		  Invoke.Login_gmail();
		  Invoke.Compose_mail();
	}
	
	@SuppressWarnings({ "static-access" })
	public static void irctc_activity() throws Exception {
		  new Invoke();
		  Invoke.Ticket_irctc();
//		  Invoke.Compose();
	}
	
	@SuppressWarnings({ "static-access" })
	public static void customer_activity() throws Exception {
		  new Invoke();
		  Invoke.Customer_form();
//		  Invoke.Compose();
	}

}
