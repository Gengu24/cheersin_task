package pageModules;
import java.awt.AWTException;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMessage;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.AgeFileFilter;
import org.apache.commons.lang.time.DateUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.monte.media.Format;
import org.monte.media.FormatKeys.MediaType;
import org.monte.screenrecorder.ScreenRecorder;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.monte.media.FormatKeys.EncodingKey;
import static org.monte.media.FormatKeys.FrameRateKey;
import static org.monte.media.FormatKeys.KeyFrameIntervalKey;
import static org.monte.media.FormatKeys.MIME_AVI;
import static org.monte.media.FormatKeys.MediaTypeKey;
import static org.monte.media.FormatKeys.MimeTypeKey;
import static org.monte.media.VideoFormatKeys.CompressorNameKey;
import static org.monte.media.VideoFormatKeys.DepthKey;
import static org.monte.media.VideoFormatKeys.ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE;
import static org.monte.media.VideoFormatKeys.QualityKey;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileWriter;

import org.monte.media.math.Rational;

import com.codoid.products.exception.FilloException;
//import org.apache.pdfbox.util.PDFTextStripper;
import com.relevantcodes.extentreports.LogStatus;

import pageModules.cheersIn.Invoke;
import testBase.TestBase;

public class Common_Functions extends TestBase {
	

	public static final String USER_DIR = "user.dir";
    public static final String DOWNLOADED_FILES_FOLDER = "OutputVideo";
    Properties emailProperties;
	Session mailSession;
	MimeMessage emailMessage;

    private static ScreenRecorder screenRecorder;
	public static void textBoxInput(WebElement tbObject, String tbName, String tbValue) throws IOException, InterruptedException {

		try {
			tbObject.sendKeys(tbValue);

			logMessage(tbValue + " is entered into the " + tbName + " Textbox field.");
		} catch (Exception e) {
			logErrorMessage(tbValue + " is not entered into the " + tbName + " Textbox field.");
			logErrorMessage(e.getLocalizedMessage());
		}
	}

	public static String res_mail() {
		// ("yyyy/MM/dd HH:mm:ss");
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");

		// get current date time with Date()
		Date date = new Date();
		String date1 = dateFormat.format(date);
		String eMail1 = "test" + date1 + "@integra.com";
		Common_Functions.logMessage("New Email Generated : " + eMail1);
		return eMail1;
	}
	
	public static int deletevideofiles(String value,int daycount)
	{
		
		
		int filecount =0;
		Date oldestAllowedFileDate = DateUtils.addDays(new Date(), -daycount); //minus days from current date
	    File targetDir = new File(value);
		Iterator<File> filesToDelete = FileUtils.iterateFiles(targetDir, new AgeFileFilter(oldestAllowedFileDate), null);
		    //if deleting subdirs, replace null above with TrueFileFilter.INSTANCE
	   while (filesToDelete.hasNext())
		    {
		    	filecount++;
		        FileUtils.deleteQuietly(filesToDelete.next());
		    }
		    return filecount;
	
	}

	public static void sideMenuNavigation(String menuPath) throws InterruptedException {

		String[] menuList = menuPath.split("\\|");
		for (int i = 0; i < menuList.length; i++) {
			if (i == 0) {
				clickMenu(menuList[i], "menu-main");
				Thread.sleep(5000);
			} else {
				clickMenu(menuList[i], "menu-sub");
			}
		}
	}

	public static void clickMenu(String linkname, String menuType) {

		WebElement menuBar = driver.findElement(By.id("menu"));
		List<WebElement> allretchoose = menuBar.findElements(By.className(menuType));

		// System.out.println("Total Choose is : " + allretchoose.size());
		for (WebElement Allretchoose : allretchoose) {
			if (Allretchoose.getText().equals(linkname)) {
				Allretchoose.click();
				System.out.println(Allretchoose.getText() + " link is clicked.");
				break;
			}
		}
	}

	public static String getDatefromToday(int days) {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, days);
		return dateFormat.format(cal.getTime());
	}
	
	public static String getDatefromToday(int days, String format) 
	{
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, days);
		return dateFormat.format(cal.getTime());
	}
	

		
	public static String readpdf(String path) throws IOException
	{
				
	  	 String pdfvalue="";
		 URL url = new URL(path);
         BufferedInputStream file = new BufferedInputStream(url.openStream());
         PDDocument document = null;
         document = PDDocument.load(file);
         pdfvalue = new org.apache.pdfbox.text.PDFTextStripper().getText(document);
         System.out.println("PDF Content Start  --"+pdfvalue+ " Pdf content END -----");
         document.close();
				return pdfvalue;
	}
	

	public static String getlatestfile()
	{
		 String filepath = null;
		String downloadfold = System.getProperty("user.home")+"\\Downloads";
		Path parentFolder = Paths.get(downloadfold);		
		Optional<File> mostRecentFile =Arrays
			        .stream(parentFolder.toFile().listFiles())
			        .filter(f -> f.isFile())
			        .max((f1, f2) -> Long.compare(f1.lastModified(),f2.lastModified()));			 
		 
		if (mostRecentFile.isPresent())		
		{
		    File mostRecent = mostRecentFile.get();
		    filepath = mostRecent.getPath();
		    System.out.println("most recent is " + mostRecent.getPath());
		} 		
		else 
		{
		    System.out.println("folder is empty!");
		}		
		return  filepath;
	}
	
	public static void logMessage_withScreenshot(String messageToLog ) {
		try {
			System.out.println(messageToLog);
			screenshotdesc = messageToLog.replace(" ", "_");
			img = capture(TestBase.project, driver);

			test.log(LogStatus.PASS, test.addScreenCapture(img)+screenshotdesc);
		} catch (Exception e) {
		}
	}

	public static void logMessage(String messageToLog) {
		try {
			System.out.println(messageToLog);
		} catch (Exception e) {
		}
	}

	public static void logErroMessage_Stop(String messageToLog) {
		try {
			System.out.println(messageToLog);
			Common_Functions.Kill_Browser();
		} catch (Exception e) {
		}
	}

	public static void logErrorMessage(String messageToLog) throws InterruptedException {
		fail = true;
		System.err.println(messageToLog);
		try {
			img = capture(TestBase.project, driver);
		} catch (IOException e) {
			e.printStackTrace();
		}
		test.log(LogStatus.FAIL, test.addScreenCapture(img) + messageToLog);
		driver.navigate().refresh();
		Thread.sleep(8000);
		Actions actn =new Actions(driver);
		actn.sendKeys(Keys.ENTER).perform();
		Thread.sleep(15000);
	}
	
	public static String returnTodayDateTime()
	{
		DateFormat dateFormat = new SimpleDateFormat("hhmmss-ddMMyyyy");
		Date date = new Date();
		 String dateformatnow=dateFormat.format(date);
		System.out.println(dateformatnow);
		return dateformatnow;
	}
	
	public static String returnTodayDateTime(String formate) 
	{
		DateFormat dateFormat = new SimpleDateFormat(formate);
		Date date = new Date();
		String dateformatnow = dateFormat.format(date);
		return dateformatnow;
	}

	public static void switchDefault() {

		try {
			driver.switchTo().defaultContent();
		} catch (Throwable ex) {
			System.out.println("Error occured while switching the frame");
			System.out.println(ex.getMessage());
		}
	}

	public static void switchFrame(int frameId) {

		try {
			driver.switchTo().frame(frameId);
		} catch (Throwable ex) {
			System.out.println("Error occured while switching the frame");
			System.out.println(ex.getMessage());
		}
	}

	public static void alertAccept() {

		try {
			Alert alert = driver.switchTo().alert();
			logMessage(alert.getText());
			alert.accept();
			driver.switchTo().defaultContent();
		} catch (Exception ex) {
			driver.switchTo().defaultContent();
		}
	}

	/**
	 * Updated by : Reka Linganathan on : 03/05/2016 Updated script to kill browsers
	 * in MAC OS
	 */

	public static void Kill_Browser() throws IOException {

		String os = System.getProperty("os.name");
		// Common_Functions.logMessage("OS Name - " + os);
		if (os.contains("Windows")) {
			
			Runtime.getRuntime().exec("taskkill /F /IM firefox.exe");
			Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
			Runtime.getRuntime().exec("taskkill.exe /F /IM chrome.exe");
			//Runtime.getRuntime().exec("taskkill.exe /F /IM chromedriver1.exe");
		}
		try {
			if (os.contains("Mac")) {
				Runtime.getRuntime().exec("pkill firefox");
				Runtime.getRuntime().exec("pkill safari");
			}
		} catch (Exception e) {
		}
	}

	/**
	 * This method identifies the object using "id" value
	 * <p>
	 * This method always returns the WebElement (i.e Object) if it is available. If
	 * the object is not available it returns null.
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param idVal
	 *            (String) This is value of the "id" attribute of the object
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @return If the object is identified it return the object as WebElement else
	 *         it will return null
	 * @throws InterruptedException 
	 * @throws IOException
	 * 
	 */

	public static WebElement findObjectById(WebDriver driver, String idVal, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.id(idVal));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	public static WebElement findObjectByTagName(WebDriver driver, String idVal, String objName) throws IOException, InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.tagName(idVal));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	/**
	 * This method identifies the object using "xpath" value
	 * <p>
	 * This method always returns the WebElement (i.e Object) if it is available. If
	 * the object is not available it returns null.
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param xpathVal
	 *            (String) This is value of the "id" attribute of the object
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @return If the object is identified it return the object as WebElement else
	 *         it will return null
	 * @throws InterruptedException 
	 * @throws IOException
	 * 
	 */

	public static WebElement findObjectByxPath(WebDriver driver, String xpathVal, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.xpath(xpathVal));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	public static List<WebElement> findObjectsByxPath(WebDriver driver, String xpathVal, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			List<WebElement> webObj = driver.findElements(By.xpath(xpathVal));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	/**
	 * This method identifies the object using "xpath" value
	 * <p>
	 * This method always returns the WebElement (i.e Object) if it is available. If
	 * the object is not available it returns null.
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param xpathVal
	 *            (String) This is value of the "id" attribute of the object
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @return If the object is identified it return the object as WebElement else
	 *         it will return null
	 * @throws InterruptedException 
	 * 
	 */

	public static WebElement findObjectBylinkText(WebDriver driver, String linkValue, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.linkText(linkValue));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	public static WebElement findObjectByclassName(String Value, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.className(Value));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	/**
	 * This method identifies appropriate method for object identification. For
	 * example , if you want to identify the object with "id",it will call
	 * findObjectById method to identify the object.
	 * <p>
	 * This method always returns the WebElement (i.e Object) if it is available. If
	 * the object is not available it returns null.
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param attr
	 *            (String) This is the attribute value using which we will identify
	 *            the object. Possible values are "id", "class", "name","xpath",
	 *            "class_contains"
	 * @param attrVal
	 *            (String) This is the value of the attribute
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @return If the object is identified it return the object as WebElement else
	 *         it will return null
	 * @throws InterruptedException 
	 * 
	 */

	public static WebElement findObject(WebDriver driver, String attr, String attrVal, String objName,
			String... tagName) throws InterruptedException {

		switch (attr) {
		// identifies object by id value
		case "id":
			return findObjectById(driver, attrVal, objName);

		case "name":
			return findObjectByName(driver, attrVal, objName);

		// identifies object by id value
		case "xpath":
			return findObjectByxPath(driver, attrVal, objName);

		case "css":
			return findObjectByCSS(driver, attrVal, objName);

		case "className":
			return findObjectByclass(driver, attrVal, objName);

		case "class":
			return findObjectByclass(driver, attrVal, objName);

		case "linkText":
			return findObjectBylinkText(driver, attrVal, objName);
		default:
			logErrorMessage("The given attribute value " + attr
					+ " may be invalid or it is not yet programmed. Please verify common_Functions.findObject method");
			return null;
		}
	}

	/**
	 * This method identifies the object using "class" value
	 * <p>
	 * This method always returns the WebElement (i.e Object) if it is available. If
	 * the object is not available it returns null.
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param className
	 *            (String) This is value of the "class name" attribute of the object
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @return If the object is identified it return the object as WebElement else
	 *         it will return null
	 * @throws InterruptedException 
	 * 
	 */

	public static WebElement findObjectByclass(WebDriver driver, String className, String objName) throws InterruptedException {

		try {
			WebElement webObj = driver.findElement(By.className(className));
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	public static WebElement findObjectByCSS(WebDriver driver, String CSSValue, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.cssSelector(CSSValue));
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	
	 public static void startRecording(String project) throws Exception
	 
	 {
	       // String file11 = System.getProperty(USER_DIR) + "//OutputVideo";

	        
	        GraphicsConfiguration gc = GraphicsEnvironment
	                .getLocalGraphicsEnvironment()
	                .getDefaultScreenDevice()
	                .getDefaultConfiguration();
	             
	        // initialize the screen recorder:
	        // - default graphics configuration
	        // - full screen recording
	        // - record in AVI format
	        // - 15 frames per second
	        // - black mouse pointer
	        // - no audio
	        // - save capture to predefined location
	             
	                screenRecorder = new ScreenRecorder(gc,
	                null, new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
	                new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
	                    CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
	                    DepthKey, 24, FrameRateKey, Rational.valueOf(15),
	                    QualityKey, 1.0f,
	                    KeyFrameIntervalKey, 15 * 60),
	                new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, "black",
	                    FrameRateKey, Rational.valueOf(30)),null, new File(project));
       
	        screenRecorder.start();       
	    }

	    public static void stopRecording() throws Exception
	    
	    {
	        screenRecorder.stop();
	    }
	
	/**
	 * This method is used to enter value in a Textbox.
	 * <p>
	 * This will identify the Textbox using the give identification parameters
	 * (attr,attrVal & tagName) If the textbox is identified succussfully it will
	 * enter the given value in the textbox. Else it will log an error message
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param attr
	 *            (String) This is the attribute value using which we will identify
	 *            the object. Possible values are "id", "class", "name","xpath",
	 *            "class_contains"
	 * @param attrVal
	 *            (String) This is the value of the attribute
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @param ValuetoEnter
	 *            (String) This value will be entered into the textbox
	 * @param tagName
	 *            (String) tagName of the html attribute. This parameter will be
	 *            application only if the "attr" is "class_contains". For other attr
	 *            its optional.
	 * @throws IOException
	 * @throws InterruptedException 
	 */

	public static void enterTextBoxValue(WebDriver driver, String attr, String attrVal, String objName,
			String ValuetoEnter, String... tagName) throws IOException, InterruptedException {

		// identify the object
		WebElement webObj = findObject(driver, attr, attrVal, objName, tagName);

		if (webObj != null) {
			try {
				webObj.clear();
				webObj.sendKeys(ValuetoEnter);
				logMessage(ValuetoEnter + " is entered into " + objName);
			} catch (Exception e) {
				logErrorMessage("There is an Exception while entering " + ValuetoEnter + " in the " + objName);
			}
		}
	}

	/**
	 * This method is used to enter value in a Textbox.
	 * <p>
	 * This will identify the Textbox using the give identification parameters
	 * (attr,attrVal & tagName) If the textbox is identified succussfully it will
	 * enter the given value in the textbox. Else it will log an error message
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param attr
	 *            (String) This is the attribute value using which we will identify
	 *            the object. Possible values are "id", "class", "name","xpath",
	 *            "class_contains"
	 * @param attrVal
	 *            (String) This is the value of the attribute
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @param ValuetoEnter
	 *            (String) This value will be entered into the textbox
	 * @param tagName
	 *            (String) tagName of the html attribute. This parameter will be
	 *            application only if the "attr" is "class_contains". For other
	 *            attr, it is optional.
	 * @throws InterruptedException 
	 */

	public static void clickOnWebElement(WebDriver driver, String attr, String attrVal, String objName,
			String... tagName) throws InterruptedException {

		// identify the object
		WebElement webObj = findObject(driver, attr, attrVal, objName, tagName);

		if (webObj != null) {
			try {
				webObj.click();
				logMessage(objName + " is clicked.");
			} catch (Exception e) {
				logErrorMessage("There is an Exception while clicking " + objName);
			}
		}
	}

	/**
	 * This method is used to select City name in the Flight Search panel
	 * <p>
	 * This method will identify the city name dropdown and use keyboard actions to
	 * select correct city name
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param cityname
	 *            Cityname - It should be the Airport code for that city which will
	 *            have 3 characters (Eg: LAS, FLL)
	 * @param idVal
	 *            (String) This is the idvalue of the combobox For Departure city -
	 *            "sfrom" For Destincation city - "sto"
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * 
	 */

	public static void selectCityValue(WebDriver driver, String cityname, String idVal, String objName)
			throws InterruptedException {

		driver.findElement(By.name(idVal)).click();
		Thread.sleep(2000);
		driver.findElement(By.name(idVal)).sendKeys(Keys.DOWN);
		String cmbVal = driver.findElement(By.name(idVal)).getAttribute("value");

		int countLoop = 0;
		while (!cmbVal.contains(" (" + cityname + ")")) {
			if (countLoop == 0) {
				driver.findElement(By.name(idVal)).sendKeys(Keys.UP);
			} else {
				driver.findElement(By.name(idVal)).sendKeys(Keys.DOWN);
			}
			cmbVal = driver.findElement(By.name(idVal)).getAttribute("value");
			countLoop++;
			if (countLoop > 130) {
				break;
			}
		}
		driver.findElement(By.name(idVal)).sendKeys(Keys.TAB);
		cmbVal = driver.findElement(By.name(idVal)).getAttribute("value");
		if (cmbVal.contains(" (" + cityname + ")")) {
			logMessage(cmbVal + " is selected in " + objName + ".");
		} else {
			logErrorMessage(cityname + " is not selected in " + objName + ".");
		}
	}

	/**
	 * This method is used to select value from dropdown or combobox.
	 * <p>
	 * This will identify the combobox using the give identification parameters
	 * (attr,attrVal & tagName) If the combobox is identified succussfully it will
	 * select the given value from it. Else it will log an error message
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param attr
	 *            (String) This is the attribute value using which we will identify
	 *            the object. Possible values are "id", "class", "name","xpath",
	 *            "class_contains"
	 * @param attrVal
	 *            (String) This is the value of the attribute
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @param ValuetoSelect
	 *            (String) This value will be entered into the textbox
	 * @param tagName
	 *            (String) tagName of the html attribute. This parameter will be
	 *            application only if the "attr" is "class_contains". For other attr
	 *            its optional.
	 * @throws InterruptedException 
	 */

	public static void clickOnWebElements(String attr, String attrVal, String objName, String... tagName) throws InterruptedException {

		// identify the object
		WebElement webObj = findObject(driver, attr, attrVal, objName, tagName);

		if (webObj != null) {
			try {
				webObj.click();
				logMessage(objName + " is clicked.");
			} catch (Exception e) {
				logErrorMessage("There is an Exception while clicking " + objName);
			}
		}
	}

	public static boolean verifyObjectText(String attr, String attrVal, String objName, Object expectedText,
			String... tagName) throws InterruptedException {

		// identify the object
		boolean fail = false;
		String objectText;
		WebElement webObj = findObject(driver, attr, attrVal, objName, tagName);
		if (webObj != null) {
			try {
				objectText = webObj.getText();
				logMessage(objName + " contains the text." + objectText);
				if (objectText.equals(expectedText)) {
					fail = false;
				} else {
					fail = true;
				}
			} catch (Exception e) {
				logErrorMessage("There is an Exception while getting the text form" + objName);
				fail = true;
			}
		}
		return fail;
	}

	public static void highlightandexist(WebElement obj) throws IOException, InterruptedException
	{		
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", obj);
     
    	if(obj.isDisplayed() == true)
    	{
    		String element = obj.toString();
    		Common_Functions.logMessage_withScreenshot(element+" Existing");
    	}
    	else
    	{
    		Common_Functions.logErrorMessage( obj.toString());
    	}
	}
	
	
	public static boolean compareString(String firststring, String lastname, String objname) throws InterruptedException {

		if (firststring.equalsIgnoreCase(lastname)) {
			Common_Functions.logMessage(
					"Comparision of " + objname + " passed : " + firststring + " is matched with : " + lastname);
		} else {
			Common_Functions.logErrorMessage(
					"Comparision of " + objname + " failed : " + firststring + " is not matched with : " + lastname);
		}
		return fail;
	}

	public static void selectDropdownValue(WebDriver driver, String attr, String attrVal, String objName,
			String ValuetoSelect, String... tagName) throws InterruptedException {

		WebElement dropDownObj = findObject(driver, attr, attrVal, objName, tagName);
		try {
			dropDownObj.sendKeys(ValuetoSelect);
			logMessage(ValuetoSelect + " is selected from the " + objName + " dropdown field.");

		} catch (Exception e) {
			logErrorMessage(ValuetoSelect + " is not selected from the " + objName + " dropdown field.");
			logErrorMessage(e.getLocalizedMessage());
		}
	}

	public static boolean compare_String(String firststring, String lastname, String objname) {

		boolean fail = false;
		if (firststring.equalsIgnoreCase(lastname)) {
			System.out.println(
					"Comparision of " + objname + " passed : " + firststring + " is matched with : " + lastname);
			fail = false;
		} else {
			System.out.println(
					"Comparision of " + objname + " failed : " + firststring + " is not matched with : " + lastname);
			fail = true;
		}
		return fail;
	}

	public static boolean compare_SubString(String fullstring, String substring, String name) {

		// Compare Name
		boolean fail = true;
		if (fullstring.contains(substring)) {
			System.out.println("Comparision of " + name + " passed : " + fullstring + " contains : " + substring);
			fail = false;
		} else {
			System.out
					.println("Comparision of " + name + " failed : " + fullstring + " is not contains : " + substring);
			fail = true;
		}
		return fail;
	}

	// update the stauts of Business function
	public static void updatestaus(boolean status) {
		if (status == true) {
			fail = true;
		}
	}

	public static void switchNextWindow() {

		// Switching from parent window to child window
		int i = 0;
		for (String Child_Window : driver.getWindowHandles()) 
		{
			
			if (i > 0) 
			{
				driver.switchTo().window(Child_Window);
			}
			i++;
		}
	}
	
	
	public static void quit() {

		try {
			driver.quit();
		} catch (Exception e) {
		}
	}

	public static WebElement findObjectByName(WebDriver driver, String idVal, String objName) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try {
			WebElement webObj = driver.findElement(By.name(idVal));
			logMessage("The Object " + objName + " is available.");
			return webObj;
		} catch (Exception ex) {
			logErrorMessage("The Object " + objName + " is not available.");
			return null;
		}
	}

	public static WebElement findObjectByWebelect(WebElement ele) throws InterruptedException {

		// Identifies the element & if its available it returns it
		try 
		{
			WebElement webObj = ele;
			logMessage("The Object " + webObj + " is available.");
			return webObj;
		}
		catch (Exception ex) 
		{
			logErrorMessage("The Webelement " + " is not available.");
			return null;
		}
	}

	
	public static void timeDifference(long lStartTime, long lEndTime) {
		Long timeDetailsArray[] = new Long[2];

		long difference = lEndTime - lStartTime;
		long minutes, timeInSeconds;
		long seconds;

		difference = difference / 1000;
		timeInSeconds = difference;
		minutes = timeInSeconds / 60;
		timeInSeconds = timeInSeconds - (minutes * 60);

		seconds = timeInSeconds;
		timeDetailsArray[0] = minutes;
		timeDetailsArray[1] = seconds;

		logMessage("Total time taken to complete this iteration: " + timeDetailsArray[0] + " Minute(s) "
				+ timeDetailsArray[1] + " Seconds ");
	}

	/**
	 * This method is used to check any checkBox objects.
	 * <p>
	 * This will identify the checkbox using the give identification parameters
	 * (attr,attrVal & tagName) If the checkbox is identified successfully it will
	 * check it. Else it will log an error message
	 * 
	 * @param driver
	 *            (WebDriver) WebDriver object on which we need to search the
	 *            element
	 * @param attr
	 *            (String) This is the attribute value using which we will identify
	 *            the object. Possible values are "id", "class", "name","xpath",
	 *            "class_contains"
	 * @param attrVal
	 *            (String) This is the value of the attribute
	 * @param objName
	 *            (String) This is name of object & it will be used to log messages
	 * @param tagName
	 *            (String) tagName of the html attribute. This parameter will be
	 *            application only if the "attr" is "class_contains". For other
	 *            attr, it is optional.
	 * @throws InterruptedException 
	 */

	public static void checkCheckBox(WebDriver driver, String attr, String attrVal, String objName, String... tagName) throws InterruptedException {

		// identify the object
		WebElement chkBox = findObject(driver, attr, attrVal, objName, tagName);

		if (chkBox != null) {
			try {
				chkBox.click();
				logMessage(objName + "CheckBox is checked.");
			} catch (Exception e) {
				logErrorMessage("There is an Exception while checking " + objName + " Checkbox");
			}
		}
	}

	/**
	 * Verify the UI elements in using this method
	 * 
	 * 
	 * @param attrValue
	 *            will accept an xpath for as attribute
	 * @param text
	 *            The text which appear on the script execution for the particular
	 *            xpath provided.
	 * @throws InterruptedException 
	 */
	public static void verifyElementByXpath(String attrValue, String text) throws InterruptedException {

		boolean code = Common_Functions.findObjectByxPath(driver, attrValue, text).isDisplayed();
		try 
		{
			if (code) 
			{
				// Common_Functions.logMessage("The Object " + text + " is
				// available.");
				Common_Functions.logMessage(text + " is displayed correctly\n");
			} else 
			{
				Common_Functions.logErrorMessage(text + " is not displayed correctly\n");
			}
		} catch (Exception e) {
			Common_Functions.logErrorMessage("Error while verifying " + text);
		}
	}

	public static void waitForElement(String attr, String attrValue, int time) throws IOException, InterruptedException {

		try {
			WebDriverWait wait = new WebDriverWait(driver, time);
			if (attr.equalsIgnoreCase("id")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(attrValue)));
			} else if (attr.equalsIgnoreCase("name")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(attrValue)));
			} else if (attr.equalsIgnoreCase("xpath")) {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(attrValue)));
			} else {
				Common_Functions.logMessage("Invalid attribute value passed. Use only id, name or xpath");
			}
		} catch (Exception e) {
			Common_Functions.logErrorMessage("Error while waiting for object. Object may not available.");
			e.printStackTrace();
		}
	}

	public static double ConvertPrice(String Value) 
	{
		double Price = 0.00;
		String[] price = Value.split("\\$");
		price[1] = price[1].replace(",", "");
		Price = Double.parseDouble(price[1]);
		return Price;
	}

	/*
	 * // Updated By Sasikanth //generate Random Number public static String
	 * generateRandomNumber(int length) { return
	 * RandomStringUtils.randomNumeric(length); } //generate Random Alpha Numeric
	 * public static String generateRandomAlphaNumeric(int length) { return
	 * RandomStringUtils.randomAlphanumeric(length);
	 * 
	 * } //Generate Random Alpha String static final String AB =
	 * "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; static SecureRandom
	 * rnd = new SecureRandom(); public static String generaterandomString( int len
	 * ){ StringBuilder sb = new StringBuilder( len ); for( int i = 0; i < len; i++
	 * ) sb.append( AB.charAt( rnd.nextInt(AB.length()) ) ); return sb.toString(); }
	 */

	// ********************************************************************************************
	public static void javascript_click(String attr, String attr_value, String objname) throws Exception {
		try {
			switch (attr) {

			case "xpath":
				((JavascriptExecutor) driver).executeScript("arguments[0].click();",
						driver.findElement(By.xpath(attr_value)));
				break;

			case "id":
				((JavascriptExecutor) driver).executeScript("arguments[0].click();",
						driver.findElement(By.id(attr_value)));
				break;

			case "name":
				((JavascriptExecutor) driver).executeScript("arguments[0].click();",
						driver.findElement(By.name(attr_value)));
				break;

			case "class":
				((JavascriptExecutor) driver).executeScript("arguments[0].click();",
						driver.findElement(By.className(attr_value)));
				break;

			case "linktext":
				((JavascriptExecutor) driver).executeScript("arguments[0].click();",
						driver.findElement(By.linkText(attr_value)));
				break;

			default:
				Common_Functions.logErrorMessage("The given attribute value " + attr
						+ " may be invalid or it is not yet programmed. Please verify common_Functions.presenceOfElementLocated method");
				throw new Exception();

			}
			Common_Functions.logMessage("The object " + objname + " is clicked");
		} catch (Exception e) {
			Common_Functions.logErrorMessage("The object " + objname + " is not clicked");
			throw new Exception();
		}

	}

	// *********************************************************************************************
	// Explicit Wait

	public static void Explicitwait_presenceOfElementLocated(int wait_time, String attr, String attr_value,
			String objname) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, wait_time);
		try {
			switch (attr) {

			case "xpath":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(attr_value)));
				break;

			case "id":
				wait.until(ExpectedConditions.presenceOfElementLocated(By.id(attr_value)));
				break;

			case "name":

				wait.until(ExpectedConditions.presenceOfElementLocated(By.name(attr_value)));
				break;

			case "class":

				wait.until(ExpectedConditions.presenceOfElementLocated(By.className(attr_value)));
				break;

			case "linktext":

				wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(attr_value)));
				break;

			default:
				Common_Functions.logErrorMessage("The given attribute value " + attr
						+ " may be invalid or it is not yet programmed. Please verify common_Functions.presenceOfElementLocated method");
				throw new Exception();

			}
			Common_Functions.logMessage("The object " + objname + " is present");
		} catch (Exception e) {
			Common_Functions.logErrorMessage("The object " + objname + " is not present");
			System.out.println(fail);
			System.out.println("2." + comments);
			throw new Exception();
		}

	}

	// ************************************************************************************************
	public static void Explicitwait_elementToBeClickable(int wait_time, String attr, String attr_value, String objname)
			throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, wait_time);
		try {
			switch (attr) {

			case "xpath":
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(attr_value)));
				break;

			case "id":
				wait.until(ExpectedConditions.elementToBeClickable(By.id(attr_value)));
				break;

			case "name":

				wait.until(ExpectedConditions.elementToBeClickable(By.name(attr_value)));
				break;

			case "class":

				wait.until(ExpectedConditions.elementToBeClickable(By.className(attr_value)));
				break;

			case "linktext":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(attr_value)));
				break;

			default:
				Common_Functions.logErrorMessage("The given attribute value " + attr
						+ " may be invalid or it is not yet programmed. Please verify common_Functions.presenceOfElementLocated method");
				throw new Exception();

			}
			Common_Functions.logMessage("The object " + objname + " is present");
		} catch (Exception e) {
			Common_Functions.logErrorMessage("The object " + objname + " is not present");
			throw new Exception();
		}

	}

	// **************************************************************************************************

	public static void Explicitwait_visibilityOfElementLocated(int wait_time, String attr, String attr_value,
			String objname) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, wait_time);
		try {
			
			
			switch (attr) 
			{

			case "xpath":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(attr_value)));
				break;

			case "id":
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(attr_value)));
				break;

			case "name":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(attr_value)));
				break;

			case "class":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(attr_value)));
				break;

			case "linktext":

				wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(attr_value)));
				break;

			default:
				Common_Functions.logErrorMessage("The given attribute value " + attr
						+ " may be invalid or it is not yet programmed. Please verify common_Functions.presenceOfElementLocated method");
				throw new Exception();

			}
			Common_Functions.logMessage("The object " + objname + " is visible");
			
		} catch (Exception e) {
			Common_Functions.logErrorMessage("The object " + objname + " is not visible");
			throw new Exception();
		}

	}

	// *************************************************************************************************

	public static void Explicitwait_invisibilityOfElementLocated(int wait_time, String attr, String attr_value,
			String objname) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, wait_time);
		try {
			switch (attr) {

			case "xpath":
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(attr_value)));
				
				break;

			case "id":
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(attr_value)));
				break;

			case "name":

				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.name(attr_value)));
				break;

			case "class":

				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(attr_value)));
				break;

			default:
				Common_Functions.logErrorMessage("The given attribute value " + attr
						+ " may be invalid or it is not yet programmed. Please verify common_Functions.presenceOfElementLocated method");
				throw new Exception();

			}

		} catch (Exception e) {
			Common_Functions.logErrorMessage("The object " + objname + " is still not visible");
			throw new Exception();
		}

	}
	public static void htmlimagepath(String path) throws InterruptedException, IOException
	{
		driver.quit();
		String dir = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", dir+"/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(path);
		Thread.sleep(10000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		List<WebElement> elelist = driver.findElements(By.xpath("//td/a/img"));
		
		
		for(WebElement img : elelist)
		{
			String imgsrc = img.getAttribute("src");
			System.out.println(imgsrc);			
			
			String[] imgstr = imgsrc.split(project+ "/");
			int count = imgstr.length;
			System.out.println("testcount" +count);
			for(int a =0; a<count;a++)
			{
			 System.out.println(imgstr[a]);
			}
			
			System.out.println("final string" + imgstr[1]);
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", 
                    img,  
                    "src",
                    imgstr[1]);
		}
		String val = driver.getPageSource();
		File f = new File(path);
		FileWriter writer = new FileWriter(f);
		writer.append(val);
		writer.close();
		driver.quit();
	}
	
	public static void fileupload(String path) throws InterruptedException, IOException, AWTException
	{
//		driver.quit();
		Thread.sleep(5000);
		StringSelection str = new StringSelection(System.getProperty("user.dir") + path);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		
		Thread.sleep(5000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}
	
	public static void makedir(String folder)
	{
		 File file = new File(folder);
	     if (!file.exists()) {
	    	 
	         if (file.mkdirs()) 
	         {
	        		             System.out.println("Directory is created!");
	         } 
	         else
	         {
	             System.out.println("Failed to create directory!");
	         }
	     }
	}
		
//	public static void verifydriveriWMS() throws InterruptedException, IOException, FilloException
//	{
//		try
//		{
//		 System.out.println("driver test");
//		 String driverstatus = driver.getTitle();
//		 System.out.println("driver status"+ driverstatus);
//	     if (driverstatus == null || driverstatus=="")
//	     {
//	    	 Invoke.Invoke(browser);
//	     }
//		}
//		catch(Exception e)
//		{
//			
//			Invoke.Invoke(browser);
//		}
//	}
	
	
	@SuppressWarnings("static-access")
	public static void videorecording(String outputimage,String videopath) throws IOException
	{		 
			new Common_Functions().makedir(videopath);
	        int filecnt = Common_Functions.deletevideofiles(videopath,1 );
			 System.out.println("Deleted file count :"+filecnt);     
	}
	
	 public static int deletefolder(String path)
		    	throws IOException{
		 
		 int a =0;
		 File file = new File(path);
		    	
		 if(file.isDirectory())
		 { 
		    		//directory is empty, then delete it
		  	if(file.list().length==0)
		  	{		
		       file.delete();
		      System.out.println("Directory is deleted : " + file.getAbsolutePath());
		    			
		    }
		  	else
		  	{
		    	 //list all the directory contents
		         String files[] = file.list();		     
		         for (String temp : files)
		         {
		        	      //construct the file structure
		        	File fileDelete = new File(file, temp);
		        	FileUtils.deleteQuietly(fileDelete);
		                   //recursive delete		        	      
		         }		        		
		        	   //check the directory again, if empty then delete it
		        if(file.list().length==0)
		        {
		            file.delete();
		            a++;
		        }
		    }
		    	
		 }
		    else
		    {
		    	//if file, then delete it
		    		file.delete();
		    		System.out.println("File is deleted : " + file.getAbsolutePath());
		    }
		 
		     return a;
		    }
	

		public static void switchtab(int index) 
		{
			driver.switchTo().window(tabs.get(index));	
		}

		
		public static void verifymail() throws MessagingException, IOException
		{
			  Properties props = new Properties();        
			  props.setProperty("mail.imap.ssl.enable", "true");     
			  Session mailSession = Session.getInstance(props); 
			  mailSession.setDebug(true);
			  Store mailStore = mailSession.getStore("imap");
			  mailStore.connect("outlook.office365.com", "", "");
			  Folder folderInbox = mailStore.getFolder("INBOX");
			  
			  
			  Message[] messages = folderInbox.getMessages();  
			   for (int i = 0; i < messages.length; i++) 
			   {  
			    Message message = messages[i];  
			    System.out.println("---------------------------------");  
			    System.out.println("Email Number " + (i + 1));  
			    System.out.println("Subject: " + message.getSubject());  
			    System.out.println("From: " + message.getFrom()[0]);  
			    System.out.println("Text: " + message.getContent().toString());  
			   }
		}
		
	          public static void setValueToClipboard(String value)
	          {
	        	  String val = value;
	        	  StringSelection stringSelection = new StringSelection(val);
	        	  Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	        	  clipboard.setContents(stringSelection, null);
	        	  
	          }
	 public static String getValueFromClipboard() throws UnsupportedFlavorException, IOException
	 {
		 Toolkit toolkit = Toolkit.getDefaultToolkit();
			Clipboard clipboard = toolkit.getSystemClipboard();
			String result = (String) clipboard.getData(DataFlavor.stringFlavor);
			System.out.println("String from Clipboard:" + result);

		 return result;
	 }
		
	 public static String generateimagefile(String filepath,String format) throws IOException
	 {
		 TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String currentdate = Common_Functions.returnTodayDateTime("ddMMYYYY");
			String timestamp = Common_Functions.returnTodayDateTime("HHmmss");
			String finalstring = currentdate+timestamp+format;
			dynamicimage = finalstring;
			String dest = System.getProperty("user.dir") +filepath +dynamicimage;
			File destination = new File(dest);
			FileUtils.copyFile(source, destination);
			return dest;
	 }
	 

		public static boolean waitforelementvisible(String xpath) 
		
		{
			WebDriverWait wait = new WebDriverWait(driver, 20);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));

			boolean status = element.isDisplayed();

			// if else condition
			return status;

		}
		
		
		public static boolean waitforelementinvisible(String xpath) 
			
			{
				
			boolean status =new WebDriverWait(driver, 5000).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));
			
				// if else condition
				return status;

			}

}


